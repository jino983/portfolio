 import Navbar from "./component/navbar";
 import Home from "./component/home";
 import Project from "./component/projects";
 import Skill from "./component/skills";
  import Contact from "./component/contact";
import "./App.css";
import Icon from "./component/icons";

 
 function App(){ 
  return(
  
  <div id="app">
  <Navbar/>
    <Home/>
    <Project/>
    <Skill/>
    <Contact/>
    <Icon></Icon>
    </div>
  )}

 export default App;