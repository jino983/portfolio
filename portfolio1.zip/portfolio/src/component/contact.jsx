function Contact() {
  return (
    <div id="contact">
      

      <form id="boss">
         <h2 id="con"><b>CONTACT</b></h2>
        <div id="nam">
          <label htmlFor="name">name</label>
          <input id="name" />
        </div>

        <div id="mail">
          <label htmlFor="email">email</label>
          <input id="email" />
        </div>

        <div id="mess">
          <label htmlFor="message">message</label>
          <textarea id="message"></textarea>
        </div>

        <button id="send" type="submit">send</button>

      </form>
    </div>
  );
}

export default Contact;