


function Navbar(){
    return(
        <nav id="nav">
            <p id="port">portfolio</p>
            <a href="#home" >Home</a>
            <a href="#project">Projects</a>
            <a href="#skill">Skills</a>
            <a href="#contact">Contact</a>
        </nav>
    )
}
export default Navbar;