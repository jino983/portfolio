


function Project(){
    return(
        <div id="project">
            <h2 id="h2"><b>PROJECTS</b></h2>
          <div id="main">
             <div id="p1">
                <h1><img src="bakery_dining_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg"/></h1>
               <p>a simple website that shows you the recipe of chocolate chip cookies </p>
                <a id="pa"href="https://capable-kringle-452e4b.netlify.app/"> 
               view  </a>
             </div>
             <div id="p2">
                <h1><img src="format_quote_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg"/></h1>
                <p>a quote website that shows you differnet inpirational quotes said by outstanding figures</p>
                <a id="paa"href="https://verdant-cupcake-c6db8f.netlify.app/">view</a>
             </div>
          </div> 
        </div>
    )
}
export default Project;