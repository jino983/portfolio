


function Skill(){
    return(
     <div id="skill">
        
       <div id="box">
          <h4><b>SKILLS :</b></h4>
        <div id="b1"><img src="html_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg" height="30px"></img>
           HTML    </div>
         <div id="b2"><img src="css_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg" height="30px"></img>CSS</div>
         
          <div id="b3"><img src="javascript_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg" height="30px"/>JAVASCRIPT</div>
           <div id="b4"> <img src="code_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg" height="30px" />REACT</div>
           
       </div>
         
       <div id="boxe">
        <h4><b>TOOLS :</b></h4>
        <div id="b1">  
            <img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/github/github-original.svg"  height="30px"/>
          <a href="https://github.com/">github</a> </div>
         <div id="b2">
            <img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/vscode/vscode-original.svg" height="30px"/>
          <a href="https://code.visualstudio.com/">vscode</a></div>
         
          
       </div>
          
     </div>   
    )
}
export default Skill;