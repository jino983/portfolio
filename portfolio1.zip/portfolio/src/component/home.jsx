
function Home(){

return(<div id="home">
    <div className="my" >
   <p id="p" > HEY there,</p>
   <h2><b>i'm <span>NOUR</span><br/>
    frontend engineer</b>
   </h2>
   <p className="front"> i build modern websites with heigh levels of pricision  </p> 
    </div>
    <img id="im"src="Digital Efficiency.jfif" height="450" width="450"/>
 

</div>)


}
export default Home;